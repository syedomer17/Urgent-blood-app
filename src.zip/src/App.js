import { useState } from "react";
import { supabase } from "./supabase";
const API_KEY = import.meta.env.VITE_GEMINI_API_KEY;
const BLOOD_COMPATIBILITY = {
  "A+": ["A+", "AB+"],
  "A-": ["A+", "A-", "AB+", "AB-"],
  "B+": ["B+", "AB+"],
  "B-": ["B+", "B-", "AB+", "AB-"],
  "AB+": ["AB+"],
  "AB-": ["AB+", "AB-"],
  "O+": ["A+", "B+", "AB+", "O+"],
  "O-": ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"],
};

const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
const CITIES = ["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai", "Kolkata", "Pune", "Jaipur", "Ahmedabad", "Lucknow"];

const initialDonors = [
  { id: 1, name: "Arjun Mehta", blood: "O+", city: "Mumbai", phone: "9876543210", available: true },
  { id: 2, name: "Priya Sharma", blood: "A-", city: "Delhi", phone: "9876543211", available: true },
  { id: 3, name: "Rohit Verma", blood: "B+", city: "Hyderabad", phone: "9876543212", available: false },
  { id: 4, name: "Sneha Iyer", blood: "AB+", city: "Bangalore", phone: "9876543213", available: true },
  { id: 5, name: "Karan Singh", blood: "O-", city: "Mumbai", phone: "9876543214", available: true },
  { id: 6, name: "Divya Nair", blood: "A+", city: "Chennai", phone: "9876543215", available: true },
  { id: 7, name: "Amit Patel", blood: "B-", city: "Ahmedabad", phone: "9876543216", available: false },
  { id: 8, name: "Meera Joshi", blood: "AB-", city: "Pune", phone: "9876543217", available: true },
];

const initialHospitals = [
  { id: 1, name: "Apollo Hospital", city: "Mumbai", email: "apollo@hospital.com", password: "apollo123", phone: "9988776655", status: "verified", licenseFileName: "apollo_license.pdf", requests: [] },
  { id: 2, name: "AIIMS Delhi", city: "Delhi", email: "aiims@hospital.com", password: "aiims123", phone: "9988776644", status: "pending", licenseFileName: "aiims_license.pdf", requests: [] },
];

const TABS = ["🔍 Find Donor", "🩸 Register Donor", "🏥 Hospital", "🛡️ Admin"];

export default function BloodDonorApp() {
  const [activeTab, setActiveTab] = useState(0);
  const [donors, setDonors] = useState(initialDonors);
  const [hospitals, setHospitals] = useState(initialHospitals);

  const [searchBlood, setSearchBlood] = useState("");
  const [searchCity, setSearchCity] = useState("");
  const [matches, setMatches] = useState(null);

  const [donorForm, setDonorForm] = useState({ name: "", blood: "", city: "", phone: "", available: true });
  const [donorStep, setDonorStep] = useState("form"); // form | upload | verifying | verified | rejected
  const [donorBillFile, setDonorBillFile] = useState(null);
  const [donorBillName, setDonorBillName] = useState("");
  const [donorBillBase64, setDonorBillBase64] = useState(null);
  const [donorBillMime, setDonorBillMime] = useState(null);
  const [donorVerifyProgress, setDonorVerifyProgress] = useState(0);
  const [donorVerifyStage, setDonorVerifyStage] = useState(0);
  const [donorRejectReason, setDonorRejectReason] = useState("");
  const [donorAiResult, setDonorAiResult] = useState(null);

  const [hospView, setHospView] = useState("login");
  const [loggedHospital, setLoggedHospital] = useState(null);
  const [hospLoginEmail, setHospLoginEmail] = useState("");
  const [hospLoginPass, setHospLoginPass] = useState("");
  const [hospLoginError, setHospLoginError] = useState("");
  const [hospRegForm, setHospRegForm] = useState({ name: "", city: "", email: "", phone: "", password: "", licenseFileName: "" });
  const [hospRegDone, setHospRegDone] = useState(false);
  const [urgentForm, setUrgentForm] = useState({ blood: "", units: "", notes: "" });
  const [hospMatches, setHospMatches] = useState(null);
  const [hospSearchBlood, setHospSearchBlood] = useState("");

  const [adminPass, setAdminPass] = useState("");
  const [adminUnlocked, setAdminUnlocked] = useState(false);
  const [adminError, setAdminError] = useState(false);
  const [adminTab, setAdminTab] = useState("donors");

  const [adminEmail, setAdminEmail] = useState("");
  const [adminPassword, setAdminPassword] = useState("");


  const [toast, setToast] = useState(null);

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3200);
  };

  const handleSearch = () => {
    if (!searchBlood) return showToast("Please select a blood group", "error");
    const compatible = BLOOD_COMPATIBILITY[searchBlood] || [];
    setMatches(donors.filter(d => compatible.includes(d.blood) && (searchCity ? d.city === searchCity : true)));
  };
  const handleAdminLogin = async () => {

    const { data, error } = await supabase.auth.signInWithPassword({
      email: adminEmail,
      password: adminPassword
    });

    if (error) {
      setAdminError(true);
    } else {
      setAdminUnlocked(true);
    }

  };


  const handleDonorRegister = () => {
    if (!donorForm.name || !donorForm.blood || !donorForm.city || !donorForm.phone) return showToast("Please fill all fields", "error");
    if (donorForm.phone.length < 10) return showToast("Enter a valid phone number", "error");
    setDonorStep("upload");
  };

  const handleDonorBillUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp", "application/pdf"];
    if (!allowedTypes.includes(file.type)) return showToast("Please upload JPG, PNG, or PDF only", "error");
    setDonorBillFile(file);
    setDonorBillName(file.name);
    setDonorBillMime(file.type);
    const reader = new FileReader();
    reader.onload = () => setDonorBillBase64(reader.result.split(",")[1]);
    reader.readAsDataURL(file);
  };

  const handleDonorVerify = async () => {
    if (!donorBillFile || !donorBillBase64) return showToast("Please upload your government hospital bill", "error");
    setDonorStep("verifying");
    setDonorVerifyProgress(0);
    setDonorVerifyStage(0);

    // Animate stages while AI processes
    const stageDurations = [600, 700, 700, 600, 500];
    let elapsed = 0;
    stageDurations.forEach((d, i) => {
      setTimeout(() => setDonorVerifyStage(i), elapsed);
      elapsed += d;
    });
    const totalAnim = stageDurations.reduce((a, b) => a + b, 0);
    const progressInterval = setInterval(() => {
      setDonorVerifyProgress(p => p < 90 ? p + 1 : p);
    }, totalAnim / 90);

    try {
      const isImage = donorBillMime.startsWith("image/");
      const contentBlock = isImage
        ? { type: "image", source: { type: "base64", media_type: donorBillMime, data: donorBillBase64 } }
        : { type: "document", source: { type: "base64", media_type: "application/pdf", data: donorBillBase64 } };

      const response = await fetch(
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyCoILg1lxf6ZV333hF5WPYWLowz8XMN9og",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            contents: [
              {
                role: "user",
                parts: [
                  {
                    inlineData: {
                      mimeType: donorBillMime,
                      data: donorBillBase64
                    }
                  },
                  {
                    text: `You are an AI document verification system for a blood donor platform.

Analyze the uploaded document carefully.

Determine:
1. Whether the document is a government hospital bill or medical document.
2. Whether the document contains a bill number, receipt number, registration number, or invoice number.
3. Whether the document appears authentic and readable.

Return ONLY valid JSON. Do not include explanations, text, or markdown.

JSON format:

{
"isHospitalDocument": true or false,
"hasBillNumber": true or false,
"billNumber": "bill number if found, otherwise null",
"hospitalName": "hospital name if found, otherwise null",
"patientName": "patient name if found, otherwise null",
"documentType": "OPD Bill, Discharge Summary, Lab Report, etc, otherwise null",
"verified": true or false,
"rejectionReason": "clear reason if verification fails, otherwise null",
"confidence": "high, medium, or low"
}

Return ONLY the JSON object.`
                  }
                ]
              }
            ]
          })
        }
      );

      clearInterval(progressInterval);
      setDonorVerifyProgress(100);
      await new Promise(r => setTimeout(r, 400));

      /// ⭐ ADD THIS PART HERE
      const rawText = await response.text();
      console.log("GEMINI RAW RESPONSE:", rawText);
      if (!response.ok) {
        console.error("Gemini API Error:", rawText);
        throw new Error("Gemini request failed");
      }
      const data = JSON.parse(rawText);

      const raw = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";

      let result;

      try {
        const cleaned = raw
          .replace(/```json/g, "")
          .replace(/```/g, "")
          .trim();
        const jsonMatch = cleaned.match(/\{[\s\S]*\}/);

        if (jsonMatch) {
          result = JSON.parse(jsonMatch[0]);
        } else {
          throw new Error("No JSON found");
        }
      } catch (e) {
        console.log("AI RAW RESPONSE:", raw);
        result = {
          verified: false,
          hasBillNumber: false,
          rejectionReason: "AI could not read the document properly."
        };
      }

      /// ⭐ YOUR EXISTING CODE CONTINUES
      if (result.verified && result.hasBillNumber) {

        const filePath = `verification/${Date.now()}_${donorBillFile.name}`;

        const { error } = await supabase.storage
          .from("documents")
          .upload(filePath, donorBillFile);

        if (error) {
          console.log(error);
        }

        setDonors(prev => [
          ...prev,
          {
            ...donorForm,
            id: Date.now(),
            verified: true,
            document: filePath
          }
        ]);

        setDonorStep("verified");
        showToast("Document verified! Donor registered 🎉");

      } else {

        setDonorRejectReason(
          result.rejectionReason ||
          (result.hasBillNumber === false
            ? "No government bill number found in the document."
            : "Document could not be verified as a valid government hospital bill.")
        );

        setDonorStep("rejected");
      }
    } catch (err) {
      clearInterval(progressInterval);
      setDonorRejectReason("Verification service unavailable. Please try again.");
      setDonorStep("rejected");
    }
  };

  const handleHospLogin = () => {
    const h = hospitals.find(h => h.email === hospLoginEmail && h.password === hospLoginPass);
    if (!h) { setHospLoginError("Invalid email or password."); return; }
    if (h.status === "pending") { setHospLoginError("Your account is pending admin verification."); return; }
    if (h.status === "rejected") { setHospLoginError("Your account was rejected. Contact admin."); return; }
    setLoggedHospital(h);
    setHospView("dashboard");
    setHospLoginError("");
    showToast(`Welcome, ${h.name}! ✅`);
  };

  const handleHospRegister = () => {
    const { name, city, email, phone, password, licenseFileName } = hospRegForm;
    if (!name || !city || !email || !phone || !password) return showToast("Fill all fields", "error");
    if (!licenseFileName) return showToast("Please upload your license/document", "error");
    if (hospitals.find(h => h.email === email)) return showToast("Email already registered", "error");
    const newHosp = { id: Date.now(), name, city, email, phone, password, licenseFileName, status: "verified", requests: [] };
    setHospitals(prev => [...prev, newHosp]);
    setHospRegDone(true);
    showToast("Verified & registered successfully! ✅");
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) setHospRegForm(f => ({ ...f, licenseFileName: file.name }));
  };

  const handleHospMatch = () => {
    if (!hospSearchBlood) return showToast("Select blood group", "error");
    const compatible = BLOOD_COMPATIBILITY[hospSearchBlood] || [];
    const city = loggedHospital?.city;
    const sameAvail = donors.filter(d => compatible.includes(d.blood) && d.city === city && d.available);
    const otherAvail = donors.filter(d => compatible.includes(d.blood) && d.city !== city && d.available);
    const unavail = donors.filter(d => compatible.includes(d.blood) && !d.available);
    setHospMatches([...sameAvail, ...otherAvail, ...unavail]);
  };

  const handlePostRequest = () => {
    if (!urgentForm.blood || !urgentForm.units) return showToast("Fill blood group and units needed", "error");
    const req = { id: Date.now(), ...urgentForm, postedAt: new Date().toLocaleString(), status: "open" };
    const updatedReqs = [...(loggedHospital.requests || []), req];
    setHospitals(prev => prev.map(h => h.id === loggedHospital.id ? { ...h, requests: updatedReqs } : h));
    setLoggedHospital(prev => ({ ...prev, requests: updatedReqs }));
    setUrgentForm({ blood: "", units: "", notes: "" });
    showToast("Urgent request posted! 🚨");
  };

  const closeRequest = (reqId) => {
    const updatedReqs = loggedHospital.requests.map(r => r.id === reqId ? { ...r, status: "closed" } : r);
    setHospitals(prev => prev.map(h => h.id === loggedHospital.id ? { ...h, requests: updatedReqs } : h));
    setLoggedHospital(prev => ({ ...prev, requests: updatedReqs }));
  };

  const toggleDonor = (id) => setDonors(prev => prev.map(d => d.id === id ? { ...d, available: !d.available } : d));
  const deleteDonor = (id) => { setDonors(prev => prev.filter(d => d.id !== id)); showToast("Donor removed"); };
  const approveHospital = (id) => { setHospitals(prev => prev.map(h => h.id === id ? { ...h, status: "verified" } : h)); showToast("Hospital verified ✅"); };
  const rejectHospital = (id) => { setHospitals(prev => prev.map(h => h.id === id ? { ...h, status: "rejected" } : h)); showToast("Hospital rejected"); };

  const pendingCount = hospitals.filter(h => h.status === "pending").length;

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(135deg, #0a0a0a 0%, #1a0505 50%, #0a0a0a 100%)", fontFamily: "'Georgia', serif", color: "#f5e6e6", position: "relative" }}>
      <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0, background: "radial-gradient(ellipse at 20% 20%, rgba(180,0,0,0.12) 0%, transparent 60%), radial-gradient(ellipse at 80% 80%, rgba(180,0,0,0.08) 0%, transparent 60%)" }} />

      {toast && (
        <div style={{ position: "fixed", top: 24, right: 24, zIndex: 1000, background: toast.type === "error" ? "#7f1d1d" : "#14532d", color: "#fff", padding: "12px 22px", borderRadius: 8, fontSize: 14, fontFamily: "sans-serif", boxShadow: "0 4px 24px rgba(0,0,0,0.5)", border: `1px solid ${toast.type === "error" ? "#ef4444" : "#22c55e"}`, animation: "fadeIn 0.3s ease" }}>{toast.msg}</div>
      )}

      <div style={{ position: "relative", zIndex: 1, maxWidth: 720, margin: "0 auto", padding: "32px 16px" }}>

        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ fontSize: 48, marginBottom: 4 }}>🩸</div>
          <h1 style={{ fontSize: "2.4rem", fontWeight: 800, letterSpacing: "-1px", color: "#fff", margin: 0, textShadow: "0 0 40px rgba(220,38,38,0.6)" }}>BloodBridge</h1>
          <p style={{ color: "#f87171", marginTop: 6, fontSize: 14, fontFamily: "sans-serif", letterSpacing: 1 }}>URGENT BLOOD DONOR MATCHING</p>
        </div>

        <div style={{ display: "flex", background: "rgba(255,255,255,0.05)", borderRadius: 12, padding: 4, marginBottom: 28, border: "1px solid rgba(255,255,255,0.08)", gap: 2 }}>
          {TABS.map((tab, i) => (
            <button key={i} onClick={() => setActiveTab(i)} style={{ flex: 1, padding: "10px 4px", border: "none", borderRadius: 9, cursor: "pointer", fontFamily: "sans-serif", fontWeight: 600, fontSize: 12, background: activeTab === i ? "linear-gradient(135deg, #dc2626, #991b1b)" : "transparent", color: activeTab === i ? "#fff" : "#ccc", transition: "all 0.2s", boxShadow: activeTab === i ? "0 2px 12px rgba(220,38,38,0.4)" : "none", position: "relative" }}>
              {tab}
              {i === 3 && pendingCount > 0 && <span style={{ position: "absolute", top: 3, right: 5, background: "#f59e0b", color: "#000", borderRadius: "50%", width: 16, height: 16, fontSize: 10, display: "inline-flex", alignItems: "center", justifyContent: "center", fontWeight: 800 }}>{pendingCount}</span>}
            </button>
          ))}
        </div>

        {/* TAB 0: FIND DONOR */}
        {activeTab === 0 && (
          <div>
            <Card>
              <SectionTitle>Patient Blood Group Needed</SectionTitle>
              <Label>Blood Group</Label>
              <Sel value={searchBlood} onChange={e => setSearchBlood(e.target.value)} placeholder="Select blood group">{BLOOD_GROUPS.map(b => <option key={b} value={b}>{b}</option>)}</Sel>
              <Label mt>City (optional)</Label>
              <Sel value={searchCity} onChange={e => setSearchCity(e.target.value)}><option value="">Any City</option>{CITIES.map(c => <option key={c} value={c}>{c}</option>)}</Sel>
              {searchBlood && <CompatNote blood={searchBlood} />}
              <RedBtn onClick={handleSearch} mt>🔍 Find Matching Donors</RedBtn>
            </Card>
            {matches !== null && (
              <div style={{ marginTop: 20 }}>
                <Hint>{matches.length === 0 ? "❌ No donors found. Try different filters." : `✅ ${matches.length} donor(s) found`}</Hint>
                {matches.map(d => <DonorCard key={d.id} donor={d} showContact={false} />)}
              </div>
            )}
          </div>
        )}

        {/* TAB 1: REGISTER DONOR */}
        {activeTab === 1 && (
          <div>
            {donorStep === "form" && (
              <Card>
                <SectionTitle>Register as a Blood Donor</SectionTitle>
                <Label>Full Name</Label>
                <Inp value={donorForm.name} onChange={e => setDonorForm({ ...donorForm, name: e.target.value })} placeholder="Your full name" />
                <Label mt>Blood Group</Label>
                <Sel value={donorForm.blood} onChange={e => setDonorForm({ ...donorForm, blood: e.target.value })} placeholder="Select blood group">{BLOOD_GROUPS.map(b => <option key={b} value={b}>{b}</option>)}</Sel>
                <Label mt>City</Label>
                <Sel value={donorForm.city} onChange={e => setDonorForm({ ...donorForm, city: e.target.value })} placeholder="Select city">{CITIES.map(c => <option key={c} value={c}>{c}</option>)}</Sel>
                <Label mt>Phone Number</Label>
                <Inp value={donorForm.phone} onChange={e => setDonorForm({ ...donorForm, phone: e.target.value })} placeholder="10-digit number" maxLength={10} />
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 14 }}>
                  <input type="checkbox" id="avail" checked={donorForm.available} onChange={e => setDonorForm({ ...donorForm, available: e.target.checked })} style={{ accentColor: "#dc2626", width: 15, height: 15 }} />
                  <label htmlFor="avail" style={{ color: "#ccc", fontFamily: "sans-serif", fontSize: 13 }}>I am currently available to donate</label>
                </div>
                <RedBtn onClick={handleDonorRegister} mt>Continue to Verification →</RedBtn>
              </Card>
            )}

            {donorStep === "upload" && (
              <Card>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 18 }}>
                  <button onClick={() => setDonorStep("form")} style={{ background: "none", border: "none", color: "#888", cursor: "pointer", fontSize: 18, padding: 0 }}>←</button>
                  <SectionTitle style={{ margin: 0 }}>Hospital Verification</SectionTitle>
                </div>

                {/* Donor summary */}
                <div style={{ background: "rgba(220,38,38,0.07)", border: "1px solid rgba(220,38,38,0.25)", borderRadius: 10, padding: "12px 16px", marginBottom: 20, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontWeight: 700, color: "#fff", fontSize: 15 }}>{donorForm.name}</div>
                    <div style={{ color: "#999", fontFamily: "sans-serif", fontSize: 12, marginTop: 2 }}>📍 {donorForm.city} &nbsp;·&nbsp; 📞 {donorForm.phone}</div>
                  </div>
                  <div style={{ background: "rgba(220,38,38,0.2)", border: "1px solid #dc2626", borderRadius: 20, padding: "4px 14px", fontSize: 16, fontWeight: 800, color: "#f87171" }}>{donorForm.blood}</div>
                </div>

                <div style={{ background: "rgba(147,197,253,0.06)", border: "1px solid rgba(147,197,253,0.2)", borderRadius: 10, padding: "12px 16px", marginBottom: 20, fontFamily: "sans-serif", fontSize: 13, color: "#93c5fd", lineHeight: 1.6 }}>
                  🏥 <strong>Why we need this?</strong><br />
                  To ensure donor safety and authenticity, we verify your identity using a government hospital bill. This confirms your blood group and identity before adding you to our network.
                </div>

                <Label>Upload Government Hospital Bill</Label>
                <div style={{ border: "2px dashed rgba(220,38,38,0.4)", borderRadius: 10, padding: "24px 20px", textAlign: "center", marginTop: 4, background: donorBillFile ? "rgba(34,197,94,0.06)" : "rgba(255,255,255,0.02)" }}>
                  <input type="file" id="billUpload" accept=".pdf,.jpg,.jpeg,.png" onChange={handleDonorBillUpload} style={{ display: "none" }} />
                  <label htmlFor="billUpload" style={{ cursor: "pointer", display: "block" }}>
                    {donorBillFile ? (
                      <div>
                        <div style={{ fontSize: 32, marginBottom: 6 }}>📋</div>
                        <div style={{ color: "#4ade80", fontFamily: "sans-serif", fontSize: 14, fontWeight: 600 }}>{donorBillName}</div>
                        <div style={{ color: "#4ade80", fontSize: 11, fontFamily: "sans-serif", marginTop: 5 }}>✅ Bill uploaded — ready to verify</div>
                        <div style={{ color: "#555", fontSize: 11, fontFamily: "sans-serif", marginTop: 2 }}>Click to change</div>
                      </div>
                    ) : (
                      <div>
                        <div style={{ fontSize: 36, marginBottom: 10 }}>🏥</div>
                        <div style={{ color: "#f87171", fontFamily: "sans-serif", fontSize: 14, fontWeight: 600 }}>Upload Hospital Bill</div>
                        <div style={{ color: "#555", fontSize: 12, fontFamily: "sans-serif", marginTop: 6, lineHeight: 1.5 }}>
                          Accepted: Government hospital bills, discharge summaries,<br />
                          blood test reports (PDF, JPG, PNG)
                        </div>
                      </div>
                    )}
                  </label>
                </div>
                <RedBtn onClick={handleDonorVerify} mt>🏥 Verify with Hospital Bill</RedBtn>
              </Card>
            )}

            {donorStep === "verifying" && (
              <Card>
                <div style={{ textAlign: "center", padding: "10px 0 20px" }}>
                  <div style={{ fontSize: 48, marginBottom: 16, animation: "pulse 1.2s infinite" }}>🏥</div>
                  <h2 style={{ color: "#fff", fontFamily: "sans-serif", margin: "0 0 6px", fontSize: "1.2rem" }}>Verifying with Hospital</h2>
                  <p style={{ color: "#888", fontFamily: "sans-serif", fontSize: 13, margin: "0 0 28px" }}>Please wait while we verify your document...</p>

                  {/* Progress bar */}
                  <div style={{ background: "rgba(255,255,255,0.08)", borderRadius: 100, height: 10, marginBottom: 10, overflow: "hidden" }}>
                    <div style={{ height: "100%", borderRadius: 100, background: "linear-gradient(90deg, #dc2626, #f87171)", width: `${donorVerifyProgress}%`, transition: "width 0.1s linear", boxShadow: "0 0 12px rgba(220,38,38,0.6)" }} />
                  </div>
                  <div style={{ color: "#f87171", fontFamily: "sans-serif", fontSize: 13, marginBottom: 24 }}>{donorVerifyProgress}%</div>

                  {/* Stages */}
                  {[
                    "📄 Reading document...",
                    "🏥 Checking hospital records...",
                    "🩸 Cross-verifying blood group...",
                    "👤 Confirming identity...",
                    "✅ Finalising verification...",
                  ].map((stage, i) => (
                    <div key={i} style={{
                      display: "flex", alignItems: "center", gap: 10, padding: "8px 14px",
                      borderRadius: 8, marginBottom: 6, textAlign: "left",
                      background: donorVerifyStage > i ? "rgba(34,197,94,0.1)" : donorVerifyStage === i ? "rgba(220,38,38,0.1)" : "rgba(255,255,255,0.02)",
                      border: `1px solid ${donorVerifyStage > i ? "rgba(34,197,94,0.3)" : donorVerifyStage === i ? "rgba(220,38,38,0.3)" : "rgba(255,255,255,0.05)"}`,
                      transition: "all 0.4s"
                    }}>
                      <span style={{ fontSize: 16 }}>{donorVerifyStage > i ? "✅" : donorVerifyStage === i ? "⏳" : "⬜"}</span>
                      <span style={{ color: donorVerifyStage > i ? "#4ade80" : donorVerifyStage === i ? "#f87171" : "#555", fontFamily: "sans-serif", fontSize: 13 }}>{stage}</span>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {donorStep === "verified" && (
              <Card>
                <div style={{ textAlign: "center", padding: "20px 0" }}>
                  <div style={{ fontSize: 56, marginBottom: 14 }}>🎉</div>
                  <h2 style={{ color: "#4ade80", fontFamily: "sans-serif", margin: "0 0 8px", fontSize: "1.4rem" }}>Verified & Registered!</h2>
                  <p style={{ color: "#ccc", fontFamily: "sans-serif", fontSize: 14, lineHeight: 1.7, marginBottom: 20 }}>
                    Your government hospital bill was verified successfully.<br />You are now part of the BloodBridge donor network.
                  </p>
                  <div style={{ background: "rgba(34,197,94,0.08)", border: "1px solid rgba(34,197,94,0.3)", borderRadius: 12, padding: "16px 20px", marginBottom: 16, textAlign: "left" }}>
                    <div style={{ fontWeight: 700, color: "#fff", fontSize: 16, marginBottom: 8 }}>{donorForm.name}</div>
                    <div style={{ color: "#4ade80", fontFamily: "sans-serif", fontSize: 13 }}>🩸 Blood Group: <strong>{donorForm.blood}</strong></div>
                    <div style={{ color: "#888", fontFamily: "sans-serif", fontSize: 12, marginTop: 3 }}>📍 {donorForm.city}</div>
                    {donorAiResult?.billNumber && <div style={{ color: "#93c5fd", fontFamily: "sans-serif", fontSize: 12, marginTop: 6 }}>🏷️ Bill No: <strong>{donorAiResult.billNumber}</strong></div>}
                    {donorAiResult?.hospitalName && <div style={{ color: "#93c5fd", fontFamily: "sans-serif", fontSize: 12, marginTop: 3 }}>🏥 Hospital: <strong>{donorAiResult.hospitalName}</strong></div>}
                    {donorAiResult?.documentType && <div style={{ color: "#888", fontFamily: "sans-serif", fontSize: 12, marginTop: 3 }}>📋 Document: {donorAiResult.documentType}</div>}
                    <div style={{ marginTop: 12, background: "rgba(34,197,94,0.15)", border: "1px solid #22c55e", borderRadius: 20, padding: "3px 14px", display: "inline-block", color: "#4ade80", fontSize: 11, fontFamily: "sans-serif", fontWeight: 700 }}>✓ GOVERNMENT HOSPITAL VERIFIED</div>
                  </div>
                  <button onClick={() => { setDonorStep("form"); setDonorForm({ name: "", blood: "", city: "", phone: "", available: true }); setDonorBillFile(null); setDonorBillName(""); setDonorBillBase64(null); setDonorVerifyProgress(0); setDonorVerifyStage(0); setDonorAiResult(null); }} style={{ background: "none", border: "1px solid rgba(255,255,255,0.15)", color: "#aaa", borderRadius: 8, padding: "9px 20px", cursor: "pointer", fontFamily: "sans-serif", fontSize: 13 }}>Register Another Donor</button>
                </div>
              </Card>
            )}

            {donorStep === "rejected" && (
              <Card>
                <div style={{ textAlign: "center", padding: "16px 0" }}>
                  <div style={{ fontSize: 52, marginBottom: 12 }}>❌</div>
                  <h2 style={{ color: "#f87171", fontFamily: "sans-serif", margin: "0 0 8px", fontSize: "1.3rem" }}>Verification Failed</h2>
                  <p style={{ color: "#ccc", fontFamily: "sans-serif", fontSize: 14, lineHeight: 1.7, marginBottom: 16 }}>
                    We could not verify your document.
                  </p>
                  <div style={{ background: "rgba(220,38,38,0.08)", border: "1px solid rgba(220,38,38,0.3)", borderRadius: 10, padding: "14px 18px", marginBottom: 20, textAlign: "left" }}>
                    <div style={{ color: "#f87171", fontFamily: "sans-serif", fontSize: 13, fontWeight: 700, marginBottom: 6 }}>Reason:</div>
                    <div style={{ color: "#ccc", fontFamily: "sans-serif", fontSize: 13, lineHeight: 1.6 }}>{donorRejectReason}</div>
                    {donorAiResult && (
                      <div style={{ marginTop: 12, borderTop: "1px solid rgba(255,255,255,0.07)", paddingTop: 10 }}>
                        <div style={{ color: "#666", fontFamily: "sans-serif", fontSize: 11 }}>
                          {donorAiResult.isHospitalDocument === false && "⚠️ Document does not appear to be a hospital bill. "}
                          {donorAiResult.hasBillNumber === false && "⚠️ No government bill number detected. "}
                          {donorAiResult.confidence && `Confidence: ${donorAiResult.confidence}`}
                        </div>
                      </div>
                    )}
                  </div>
                  <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 10, padding: "12px 16px", marginBottom: 20, textAlign: "left" }}>
                    <div style={{ color: "#fbbf24", fontFamily: "sans-serif", fontSize: 12, fontWeight: 700, marginBottom: 6 }}>What to upload:</div>
                    <div style={{ color: "#888", fontFamily: "sans-serif", fontSize: 12, lineHeight: 1.8 }}>
                      ✅ OPD / IPD Bill with Bill Number<br />
                      ✅ Government hospital receipt with official number<br />
                      ✅ Discharge summary with registration number<br />
                      ✅ Lab report from a government hospital<br />
                      ❌ Private clinic bills not accepted<br />
                      ❌ Blurry or cropped documents not accepted
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: 10 }}>
                    <button onClick={() => { setDonorStep("upload"); setDonorBillFile(null); setDonorBillName(""); setDonorBillBase64(null); setDonorVerifyProgress(0); setDonorVerifyStage(0); setDonorAiResult(null); }} style={{ flex: 1, background: "linear-gradient(135deg, #dc2626, #991b1b)", border: "none", color: "#fff", borderRadius: 8, padding: "10px", cursor: "pointer", fontFamily: "sans-serif", fontSize: 13, fontWeight: 700 }}>Try Again with New Document</button>
                    <button onClick={() => { setDonorStep("form"); setDonorBillFile(null); setDonorBillName(""); setDonorBillBase64(null); setDonorVerifyProgress(0); setDonorVerifyStage(0); setDonorAiResult(null); }} style={{ background: "none", border: "1px solid rgba(255,255,255,0.15)", color: "#aaa", borderRadius: 8, padding: "10px 16px", cursor: "pointer", fontFamily: "sans-serif", fontSize: 13 }}>← Back</button>
                  </div>
                </div>
              </Card>
            )}
          </div>
        )}

        {/* TAB 2: HOSPITAL */}
        {activeTab === 2 && (
          <div>
            {hospView === "login" && (
              <Card>
                <SectionTitle>🏥 Hospital Login</SectionTitle>
                <Label>Email</Label>
                <Inp value={hospLoginEmail} onChange={e => { setHospLoginEmail(e.target.value); setHospLoginError(""); }} placeholder="hospital@email.com" />
                <Label mt>Password</Label>
                <Inp type="password" value={hospLoginPass} onChange={e => { setHospLoginPass(e.target.value); setHospLoginError(""); }} placeholder="Password" />
                {hospLoginError && <ErrorMsg>{hospLoginError}</ErrorMsg>}
                <RedBtn onClick={handleHospLogin} mt>Login</RedBtn>
                <div style={{ textAlign: "center", marginTop: 14 }}>
                  <button onClick={() => setHospView("register")} style={{ background: "none", border: "none", color: "#f87171", fontFamily: "sans-serif", fontSize: 13, cursor: "pointer", textDecoration: "underline" }}>New hospital? Register here →</button>
                </div>
                <div style={{ marginTop: 14, padding: "10px 14px", background: "rgba(255,255,255,0.04)", borderRadius: 8, fontFamily: "sans-serif", fontSize: 12, color: "#666" }}>
                  Demo: <strong style={{ color: "#f87171" }}>apollo@hospital.com</strong> / <strong style={{ color: "#f87171" }}>apollo123</strong>
                </div>
              </Card>
            )}

            {hospView === "register" && !hospRegDone && (
              <Card>
                <SectionTitle>🏥 Register Hospital</SectionTitle>
                <Label>Hospital Name</Label>
                <Inp value={hospRegForm.name} onChange={e => setHospRegForm({ ...hospRegForm, name: e.target.value })} placeholder="Full hospital name" />
                <Label mt>City</Label>
                <Sel value={hospRegForm.city} onChange={e => setHospRegForm({ ...hospRegForm, city: e.target.value })} placeholder="Select city">{CITIES.map(c => <option key={c} value={c}>{c}</option>)}</Sel>
                <Label mt>Email</Label>
                <Inp value={hospRegForm.email} onChange={e => setHospRegForm({ ...hospRegForm, email: e.target.value })} placeholder="official@hospital.com" />
                <Label mt>Phone</Label>
                <Inp value={hospRegForm.phone} onChange={e => setHospRegForm({ ...hospRegForm, phone: e.target.value })} placeholder="Contact number" />
                <Label mt>Password</Label>
                <Inp type="password" value={hospRegForm.password} onChange={e => setHospRegForm({ ...hospRegForm, password: e.target.value })} placeholder="Create a password" />
                <Label mt>Upload License / Registration Document</Label>
                <div style={{ border: "2px dashed rgba(220,38,38,0.4)", borderRadius: 10, padding: "20px", textAlign: "center", marginTop: 4, background: hospRegForm.licenseFileName ? "rgba(34,197,94,0.06)" : "rgba(255,255,255,0.02)" }}>
                  <input type="file" id="licUpload" accept=".pdf,.jpg,.jpeg,.png" onChange={handleFileUpload} style={{ display: "none" }} />
                  <label htmlFor="licUpload" style={{ cursor: "pointer", display: "block" }}>
                    {hospRegForm.licenseFileName ? (
                      <div>
                        <div style={{ fontSize: 30, marginBottom: 6 }}>📄</div>
                        <div style={{ color: "#4ade80", fontFamily: "sans-serif", fontSize: 13 }}>{hospRegForm.licenseFileName}</div>
                        <div style={{ color: "#4ade80", fontSize: 11, fontFamily: "sans-serif", marginTop: 4 }}>✅ Document ready — you'll be verified instantly on submit</div>
                      </div>
                    ) : (
                      <div>
                        <div style={{ fontSize: 34, marginBottom: 8 }}>📂</div>
                        <div style={{ color: "#f87171", fontFamily: "sans-serif", fontSize: 13, fontWeight: 600 }}>Click to upload PDF, JPG, or PNG</div>
                        <div style={{ color: "#555", fontSize: 11, fontFamily: "sans-serif", marginTop: 5 }}>Upload your hospital registration certificate or medical license to get instantly verified</div>
                      </div>
                    )}
                  </label>
                </div>
                <RedBtn onClick={handleHospRegister} mt>🏥 Register & Get Verified Instantly</RedBtn>
                <div style={{ textAlign: "center", marginTop: 12 }}>
                  <button onClick={() => setHospView("login")} style={{ background: "none", border: "none", color: "#666", fontFamily: "sans-serif", fontSize: 12, cursor: "pointer" }}>← Back to login</button>
                </div>
              </Card>
            )}

            {hospView === "register" && hospRegDone && (
              <Card>
                <div style={{ textAlign: "center", padding: "24px 0" }}>
                  <div style={{ fontSize: 52, marginBottom: 12 }}>✅</div>
                  <h2 style={{ color: "#4ade80", margin: "0 0 10px", fontFamily: "sans-serif" }}>Hospital Verified!</h2>
                  <p style={{ color: "#ccc", fontFamily: "sans-serif", fontSize: 14, lineHeight: 1.7 }}>Your document was verified successfully.<br />You can now log in and access all hospital features.</p>
                  <button onClick={() => { setHospView("login"); setHospRegDone(false); setHospRegForm({ name: "", city: "", email: "", phone: "", password: "", licenseFileName: "" }); }} style={{ marginTop: 18, background: "linear-gradient(135deg, #dc2626, #991b1b)", border: "none", color: "#fff", borderRadius: 8, padding: "10px 24px", cursor: "pointer", fontFamily: "sans-serif", fontSize: 13, fontWeight: 700 }}>Go to Login →</button>
                </div>
              </Card>
            )}

            {hospView === "dashboard" && loggedHospital && (
              <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                  <div>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <h2 style={{ margin: 0, color: "#fff", fontSize: "1.15rem" }}>{loggedHospital.name}</h2>
                      <span style={{ background: "rgba(34,197,94,0.15)", border: "1px solid #22c55e", color: "#4ade80", borderRadius: 20, padding: "2px 10px", fontSize: 10, fontFamily: "sans-serif", fontWeight: 800 }}>✓ VERIFIED</span>
                    </div>
                    <div style={{ color: "#888", fontFamily: "sans-serif", fontSize: 12, marginTop: 3 }}>📍 {loggedHospital.city}</div>
                  </div>
                  <button onClick={() => { setHospView("login"); setLoggedHospital(null); setHospLoginEmail(""); setHospLoginPass(""); setHospMatches(null); }} style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", color: "#aaa", borderRadius: 7, padding: "6px 14px", cursor: "pointer", fontFamily: "sans-serif", fontSize: 12 }}>Logout</button>
                </div>

                <Card style={{ marginBottom: 18 }}>
                  <SectionTitle>🎯 Priority Donor Search</SectionTitle>
                  <p style={{ color: "#777", fontFamily: "sans-serif", fontSize: 12, margin: "0 0 12px", lineHeight: 1.5 }}>Donors in your city appear first. Full contact details visible to verified hospitals only.</p>
                  <Sel value={hospSearchBlood} onChange={e => setHospSearchBlood(e.target.value)} placeholder="Select blood group needed">{BLOOD_GROUPS.map(b => <option key={b} value={b}>{b}</option>)}</Sel>
                  {hospSearchBlood && <CompatNote blood={hospSearchBlood} />}
                  <RedBtn onClick={handleHospMatch} mt>🔍 Find Priority Donors</RedBtn>
                  {hospMatches !== null && (
                    <div style={{ marginTop: 14 }}>
                      <Hint>{hospMatches.length === 0 ? "❌ No matching donors found." : `✅ ${hospMatches.length} donor(s) found — sorted by proximity & availability`}</Hint>
                      {hospMatches.map(d => <DonorCard key={d.id} donor={d} showContact={true} priority={d.city === loggedHospital.city} />)}
                    </div>
                  )}
                </Card>

                <Card style={{ marginBottom: 18 }}>
                  <SectionTitle>🚨 Post Urgent Blood Request</SectionTitle>
                  <Label>Blood Group Needed</Label>
                  <Sel value={urgentForm.blood} onChange={e => setUrgentForm({ ...urgentForm, blood: e.target.value })} placeholder="Select blood group">{BLOOD_GROUPS.map(b => <option key={b} value={b}>{b}</option>)}</Sel>
                  <Label mt>Units Required</Label>
                  <Inp value={urgentForm.units} onChange={e => setUrgentForm({ ...urgentForm, units: e.target.value })} placeholder="e.g. 2 units" />
                  <Label mt>Additional Notes</Label>
                  <Inp value={urgentForm.notes} onChange={e => setUrgentForm({ ...urgentForm, notes: e.target.value })} placeholder="e.g. For surgery on 8th March, urgent" />
                  <RedBtn onClick={handlePostRequest} mt>🚨 Post Urgent Request</RedBtn>
                </Card>

                {loggedHospital.requests?.length > 0 && (
                  <Card>
                    <SectionTitle>📋 My Blood Requests</SectionTitle>
                    {loggedHospital.requests.map(r => (
                      <div key={r.id} style={{ background: "rgba(255,255,255,0.03)", border: `1px solid ${r.status === "open" ? "rgba(220,38,38,0.35)" : "rgba(255,255,255,0.06)"}`, borderRadius: 10, padding: "12px 16px", marginBottom: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <div>
                          <span style={{ background: "rgba(220,38,38,0.2)", border: "1px solid #dc2626", color: "#f87171", borderRadius: 10, padding: "2px 10px", fontSize: 13, fontWeight: 800, marginRight: 10 }}>{r.blood}</span>
                          <span style={{ color: "#ccc", fontFamily: "sans-serif", fontSize: 13 }}>{r.units} units</span>
                          {r.notes && <span style={{ color: "#666", fontFamily: "sans-serif", fontSize: 12, marginLeft: 8 }}>· {r.notes}</span>}
                          <div style={{ color: "#555", fontFamily: "sans-serif", fontSize: 11, marginTop: 4 }}>{r.postedAt}</div>
                        </div>
                        <div style={{ display: "flex", alignItems: "center", gap: 8, flexShrink: 0 }}>
                          <span style={{ color: r.status === "open" ? "#f87171" : "#6b7280", fontFamily: "sans-serif", fontSize: 11, fontWeight: 700 }}>{r.status === "open" ? "🔴 OPEN" : "✅ CLOSED"}</span>
                          {r.status === "open" && <button onClick={() => closeRequest(r.id)} style={{ background: "rgba(34,197,94,0.1)", border: "1px solid #22c55e", color: "#4ade80", borderRadius: 6, padding: "4px 10px", cursor: "pointer", fontSize: 11, fontFamily: "sans-serif" }}>Mark Closed</button>}
                        </div>
                      </div>
                    ))}
                  </Card>
                )}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: ADMIN */}
        {activeTab === 3 && (
          <div>
            {!adminUnlocked ? (
              <Card>
                <SectionTitle>🔒 Admin Access</SectionTitle>

                <Label>Email</Label>
                <Inp
                  type="email"
                  value={adminEmail}
                  onChange={e => { setAdminEmail(e.target.value); setAdminError(false); }}
                  placeholder="Enter admin email"
                />

                <Label mt>Password</Label>
                <Inp
                  type="password"
                  value={adminPassword}
                  onChange={e => { setAdminPassword(e.target.value); setAdminError(false); }}
                  placeholder="Enter admin password"
                />

                {adminError && <ErrorMsg>❌ Invalid email or password</ErrorMsg>}

                <RedBtn onClick={handleAdminLogin} mt>
                  Unlock Dashboard
                </RedBtn>

              </Card>

            ) : (
              <div>
                <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
                  {["donors", "hospitals"].map(t => (
                    <button key={t} onClick={() => setAdminTab(t)} style={{ flex: 1, padding: "10px", border: "none", borderRadius: 9, cursor: "pointer", fontFamily: "sans-serif", fontWeight: 600, fontSize: 13, background: adminTab === t ? "linear-gradient(135deg, #dc2626, #991b1b)" : "rgba(255,255,255,0.05)", color: adminTab === t ? "#fff" : "#ccc" }}>
                      {t === "donors" ? `🩸 Donors (${donors.length})` : `🏥 Hospitals (${hospitals.length})`}
                      {t === "hospitals" && pendingCount > 0 && <span style={{ marginLeft: 6, background: "#f59e0b", color: "#000", borderRadius: 10, padding: "1px 7px", fontSize: 10, fontWeight: 800 }}>{pendingCount} pending</span>}
                    </button>
                  ))}
                </div>
                <Card style={{ marginBottom: 20 }}>
                  <SectionTitle>📊 System Statistics</SectionTitle>

                  <div style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(3, 1fr)",
                    gap: 12,
                    marginTop: 10
                  }}>

                    <div style={{
                      background: "rgba(220,38,38,0.1)",
                      border: "1px solid rgba(220,38,38,0.3)",
                      padding: 15,
                      borderRadius: 10,
                      textAlign: "center"
                    }}>
                      <div style={{ fontSize: 22, fontWeight: "bold" }}>
                        {donors.length}
                      </div>
                      <div style={{ fontSize: 12 }}>🩸 Total Donors</div>
                    </div>

                    <div style={{
                      background: "rgba(59,130,246,0.1)",
                      border: "1px solid rgba(59,130,246,0.3)",
                      padding: 15,
                      borderRadius: 10,
                      textAlign: "center"
                    }}>
                      <div style={{ fontSize: 22, fontWeight: "bold" }}>
                        {hospitals.length}
                      </div>
                      <div style={{ fontSize: 12 }}>🏥 Hospitals</div>
                    </div>

                    <div style={{
                      background: "rgba(34,197,94,0.1)",
                      border: "1px solid rgba(34,197,94,0.3)",
                      padding: 15,
                      borderRadius: 10,
                      textAlign: "center"
                    }}>
                      <div style={{ fontSize: 22, fontWeight: "bold" }}>
                        {hospitals.reduce((total, h) =>
                          total + (h.requests?.filter(r => r.status === "open").length || 0), 0)}
                      </div>
                      <div style={{ fontSize: 12 }}>🚨 Active Requests</div>
                    </div>

                  </div>
                </Card>

                {adminTab === "donors" && (
                  <div>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12, alignItems: "center" }}>
                      <span style={{ color: "#fca5a5", fontFamily: "sans-serif", fontSize: 14, fontWeight: 600 }}>All Donors</span>
                      <span style={{ background: "#14532d", color: "#4ade80", padding: "3px 12px", borderRadius: 20, fontSize: 12, fontFamily: "sans-serif" }}>{donors.filter(d => d.available).length} Available</span>
                    </div>
                    {donors.map(d => <AdminDonorRow key={d.id} donor={d} onToggle={() => toggleDonor(d.id)} onDelete={() => deleteDonor(d.id)} />)}
                  </div>
                )}

                {adminTab === "hospitals" && (
                  <div>
                    <div style={{ marginBottom: 12, color: "#fca5a5", fontFamily: "sans-serif", fontSize: 14, fontWeight: 600 }}>Hospital Verification Queue</div>
                    {hospitals.map(h => <AdminHospitalRow key={h.id} hospital={h} onApprove={() => approveHospital(h.id)} onReject={() => rejectHospital(h.id)} />)}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
      <style>{`@keyframes fadeIn{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}} @keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.12)}} select option{background:#1a0a0a;color:#f5e6e6}`}</style>
    </div>
  );
}

function Card({ children, style }) {
  return <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 14, padding: 24, backdropFilter: "blur(8px)", ...style }}>{children}</div>;
}
function SectionTitle({ children }) {
  return <h2 style={{ color: "#fca5a5", marginTop: 0, marginBottom: 14, fontSize: "1rem", fontFamily: "sans-serif", fontWeight: 700 }}>{children}</h2>;
}
function Label({ children, mt }) {
  return <div style={{ color: "#bbb", fontSize: 12, fontFamily: "sans-serif", marginBottom: 5, marginTop: mt ? 14 : 2 }}>{children}</div>;
}
function Inp(props) {
  return <input {...props} style={{ width: "100%", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.14)", borderRadius: 8, padding: "10px 14px", color: "#fff", fontSize: 14, fontFamily: "sans-serif", outline: "none", boxSizing: "border-box" }} />;
}
function Sel({ children, placeholder, ...props }) {
  return <select {...props} style={{ width: "100%", background: "rgba(30,5,5,0.95)", border: "1px solid rgba(255,255,255,0.14)", borderRadius: 8, padding: "10px 14px", color: props.value ? "#fff" : "#777", fontSize: 14, fontFamily: "sans-serif", outline: "none", boxSizing: "border-box", cursor: "pointer" }}>
    {placeholder && <option value="">{placeholder}</option>}{children}
  </select>;
}
function RedBtn({ children, onClick, mt }) {
  return <button onClick={onClick} style={{ width: "100%", background: "linear-gradient(135deg, #dc2626, #991b1b)", border: "none", borderRadius: 9, padding: 13, color: "#fff", fontFamily: "sans-serif", fontWeight: 700, fontSize: 15, cursor: "pointer", boxShadow: "0 4px 20px rgba(220,38,38,0.35)", marginTop: mt ? 16 : 0 }}>{children}</button>;
}
function Hint({ children }) { return <p style={{ color: "#f87171", fontFamily: "sans-serif", fontSize: 13, marginBottom: 10 }}>{children}</p>; }
function ErrorMsg({ children }) { return <p style={{ color: "#f87171", fontFamily: "sans-serif", fontSize: 13, marginTop: 8 }}>{children}</p>; }
function SuccessMsg({ children }) { return <p style={{ color: "#4ade80", fontFamily: "sans-serif", fontSize: 13, marginTop: 12 }}>{children}</p>; }
function CompatNote({ blood }) {
  return <p style={{ color: "#f87171", fontSize: 11, marginTop: 6, fontFamily: "sans-serif" }}>Compatible types for <strong>{blood}</strong>: {BLOOD_COMPATIBILITY[blood]?.join(", ")}</p>;
}

function DonorCard({ donor, showContact, priority }) {
  return (
    <div style={{ background: priority ? "rgba(220,38,38,0.06)" : "rgba(255,255,255,0.03)", border: `1px solid ${donor.available ? (priority ? "rgba(220,38,38,0.45)" : "rgba(34,197,94,0.25)") : "rgba(255,255,255,0.06)"}`, borderRadius: 12, padding: "13px 18px", marginBottom: 10, display: "flex", justifyContent: "space-between", alignItems: "center", borderLeft: `4px solid ${priority ? "#dc2626" : donor.available ? "#22c55e" : "#374151"}` }}>
      <div>
        <div style={{ fontWeight: 700, fontSize: 15, color: "#fff" }}>
          {priority && <span style={{ background: "#dc2626", color: "#fff", fontSize: 9, padding: "2px 6px", borderRadius: 4, marginRight: 7, fontFamily: "sans-serif", fontWeight: 800 }}>NEARBY</span>}
          {donor.name}
        </div>
        <div style={{ fontFamily: "sans-serif", fontSize: 12, color: "#999", marginTop: 3 }}>
          📍 {donor.city}
          {showContact
            ? <span style={{ marginLeft: 10, color: "#93c5fd" }}>📞 {donor.phone}</span>
            : <span style={{ marginLeft: 8, color: "#444", fontSize: 11 }}>🔒 Login as verified hospital to see contact</span>}
        </div>
      </div>
      <div style={{ textAlign: "right", flexShrink: 0 }}>
        <div style={{ background: "rgba(220,38,38,0.2)", border: "1px solid #dc2626", borderRadius: 20, padding: "3px 12px", fontSize: 14, fontWeight: 800, color: "#f87171", marginBottom: 4 }}>{donor.blood}</div>
        <div style={{ fontSize: 11, fontFamily: "sans-serif", color: donor.available ? "#4ade80" : "#6b7280", fontWeight: 600 }}>{donor.available ? "✅ Available" : "⏸ Unavailable"}</div>
      </div>
    </div>
  );
}

function AdminDonorRow({ donor, onToggle, onDelete }) {
  return (
    <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 10, padding: "11px 14px", marginBottom: 8, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
      <div style={{ minWidth: 0 }}>
        <span style={{ fontWeight: 700, color: "#fff", marginRight: 8, fontSize: 14 }}>{donor.name}</span>
        <span style={{ background: "rgba(220,38,38,0.2)", border: "1px solid #dc2626", borderRadius: 10, padding: "1px 8px", fontSize: 11, color: "#f87171", fontWeight: 700, marginRight: 8 }}>{donor.blood}</span>
        <span style={{ color: "#555", fontFamily: "sans-serif", fontSize: 12 }}>{donor.city} · {donor.phone}</span>
      </div>
      <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
        <button onClick={onToggle} style={{ background: donor.available ? "rgba(34,197,94,0.12)" : "rgba(107,114,128,0.12)", border: `1px solid ${donor.available ? "#22c55e" : "#6b7280"}`, color: donor.available ? "#4ade80" : "#9ca3af", borderRadius: 6, padding: "4px 10px", cursor: "pointer", fontSize: 11, fontFamily: "sans-serif" }}>{donor.available ? "Available" : "Unavailable"}</button>
        <button onClick={onDelete} style={{ background: "rgba(220,38,38,0.08)", border: "1px solid #dc2626", color: "#f87171", borderRadius: 6, padding: "4px 9px", cursor: "pointer", fontSize: 12 }}>✕</button>
      </div>
    </div>
  );
}

function AdminHospitalRow({ hospital, onApprove, onReject }) {
  const colors = { verified: "#22c55e", pending: "#f59e0b", rejected: "#ef4444" };
  const bgs = { verified: "rgba(34,197,94,0.08)", pending: "rgba(245,158,11,0.08)", rejected: "rgba(239,68,68,0.08)" };
  return (
    <div style={{ background: bgs[hospital.status], border: `1px solid ${colors[hospital.status]}44`, borderRadius: 12, padding: "16px 18px", marginBottom: 14 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontWeight: 700, color: "#fff", fontSize: 15, marginBottom: 5 }}>{hospital.name}</div>
          <div style={{ fontFamily: "sans-serif", fontSize: 12, color: "#777", marginBottom: 6 }}>📍 {hospital.city} &nbsp;·&nbsp; ✉️ {hospital.email} &nbsp;·&nbsp; 📞 {hospital.phone}</div>
          {hospital.licenseFileName && (
            <div style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "rgba(147,197,253,0.08)", border: "1px solid rgba(147,197,253,0.2)", borderRadius: 6, padding: "3px 10px" }}>
              <span style={{ fontSize: 13 }}>📄</span>
              <span style={{ color: "#93c5fd", fontFamily: "sans-serif", fontSize: 12 }}>{hospital.licenseFileName}</span>
            </div>
          )}
        </div>
        <span style={{ background: bgs[hospital.status], border: `1px solid ${colors[hospital.status]}`, color: colors[hospital.status], borderRadius: 20, padding: "3px 12px", fontSize: 10, fontFamily: "sans-serif", fontWeight: 800, whiteSpace: "nowrap", flexShrink: 0 }}>{hospital.status.toUpperCase()}</span>
      </div>
      {hospital.status === "pending" && (
        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
          <button onClick={onApprove} style={{ flex: 1, background: "rgba(34,197,94,0.12)", border: "1px solid #22c55e", color: "#4ade80", borderRadius: 8, padding: "9px", cursor: "pointer", fontFamily: "sans-serif", fontSize: 13, fontWeight: 600 }}>✅ Approve & Verify</button>
          <button onClick={onReject} style={{ flex: 1, background: "rgba(239,68,68,0.1)", border: "1px solid #ef4444", color: "#f87171", borderRadius: 8, padding: "9px", cursor: "pointer", fontFamily: "sans-serif", fontSize: 13, fontWeight: 600 }}>❌ Reject</button>
        </div>
      )}
    </div>
  );
}
