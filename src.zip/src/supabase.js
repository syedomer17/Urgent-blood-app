import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "https://ulumivhroovjfcywfbcc.supabase.co";
const supabaseKey = "sb_publishable_Ly3L7Rad_rt5DNIPavgI_Q_VGDFf-He";

export const supabase = createClient(supabaseUrl, supabaseKey);